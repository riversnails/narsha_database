/*
 * (C) COPYRIGHT 2012 CRZ
 *
 * File Name : test.h
 * Author    : POOH
 * Version   : V1.0
 * Date      : 04/12/2012
 */

#ifndef __TEST_H
#define __TEST_H

/* includes */

/* functions */

void Test_LED(void);
void Test_HttpServer(void);
void Test_USB_Device_VCP(void);
void Test_USB_Host_MSC(void);
void Test_USB_Host_HID(void);

#endif  /* __TEST_H */

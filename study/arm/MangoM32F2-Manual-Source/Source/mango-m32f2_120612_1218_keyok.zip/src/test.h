/*
 * (C) COPYRIGHT 2012 CRZ
 *
 * File Name : test.h
 * Author    : POOH
 * Version   : V1.0
 * Date      : 04/12/2012
 */

#ifndef __TEST_H
#define __TEST_H

/* includes */

/* functions */

void LED_Test(void);

#endif  /* __TEST_H */

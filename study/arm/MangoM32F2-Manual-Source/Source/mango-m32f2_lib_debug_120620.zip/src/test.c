/*
 * (C) COPYRIGHT 2012 CRZ
 *
 * File Name : test.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 04/13/2012
 */

/* includes */

#include "hw_config.h"
#include "stm32f2xx_ip_dbg.h"

/* static functions */

/**
  * @brief  Inserts a delay time.
  * @param  nCount: specifies the delay time length.
  * @retval None
  */
static void delay_time_consume(__IO uint32_t nCount)
{
    /* Decrement nCount value */
    while (nCount != 0)
    {
        nCount--;
    }
}

static void delay_1_second(void)
{
    delay_time_consume(0x4FFFFF);
}

static void led_on_all (void)
{
    DevCtrl_LED_On(LED1);
    DevCtrl_LED_On(LED2);
    DevCtrl_LED_On(LED3);
}

static void led_off_all (void)
{
    DevCtrl_LED_Off(LED1);
    DevCtrl_LED_Off(LED2);
    DevCtrl_LED_Off(LED3);
}

static void led_on_off_all_mult(uint32_t count)
{
    for(; count > 0; count --)
    {
        DevCtrl_LED_Off(LED1);
        DevCtrl_LED_On(LED2);
        DevCtrl_LED_On(LED3);
        delay_1_second();

        DevCtrl_LED_On(LED1);
        DevCtrl_LED_Off(LED2);
        DevCtrl_LED_On(LED3);
        delay_1_second();

        DevCtrl_LED_On(LED1);
        DevCtrl_LED_On(LED2);
        DevCtrl_LED_Off(LED3);
        delay_1_second();
    }
}

/* global functions */

void Test_LED(void)
{
    led_on_all();
    delay_1_second();
    led_off_all();
    delay_1_second();

    led_on_off_all_mult(2);
}

void Test_Lib_DEBUG(void)
{
    GPIO_InitTypeDef GPIOA_InitStructure;
 
    /* Initialize all peripherals pointers */
    IP_Debug();

    printf("\r\n STM32F2xx Firmware Library compiled with FULL ASSERT function... \n\r");
    printf("...Run-time checking enabled  \n\r");

    /* Simulate wrong parameter passed to library function ---------------------*/
    /* To enable SPI1 clock, RCC_APB2PeriphClockCmd() function must be used and
    not RCC_APB1PeriphClockCmd() */
    RCC_APB1PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

    /* Some member of GPIOA_InitStructure structure are not initialized */
    GPIOA_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIOA_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    /*GPIOA_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;*/
    GPIOA_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIOA_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; 
    GPIO_Init(GPIOA, &GPIOA_InitStructure);
}


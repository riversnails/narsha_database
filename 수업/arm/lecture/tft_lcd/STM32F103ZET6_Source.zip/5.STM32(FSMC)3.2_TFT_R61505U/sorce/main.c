#include "stm32f10x_lib.h"
#include "ili9320.h"
#include "Picture.h"	//ͼƬģ��
GPIO_InitTypeDef GPIO_InitStructure;

void LED_Init(void)
{
      GPIO_InitTypeDef GPIO_InitStructure;
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
	
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
  	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	  GPIO_Init(GPIOG, &GPIO_InitStructure);

	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	  GPIO_Init(GPIOD, &GPIO_InitStructure);
}

void Delay_led(vu32 nCount)
{
     for(; nCount != 0; nCount--);
}
main()
{	
	LED_Init();					      //LED��ʼ��
	
	ili9320_Initializtion();		  //Һ������ʼ��
	ili9320_BackLight(1);			  //���ⳣ��

	//��ָ��������ʾһ��8x16�����ascii�ַ�
	//ili9320_PutChar(10,10,'a',0x0000,0xffff);	   
	//ili9320_PutChar(20,10,'b',0x0000,0xffff);
	//ili9320_PutChar(30,10,'c',0x0000,0xffff);
	//ili9320_PutChar(40,10,'d',0x0000,0xffff);	   
	while(1)
	{		ili9320_DrawPicture(0,0,240,320,(u8*)gImage_tupian); //��ʾͼƬ
		    Delay_led(0x8ffff); Delay_led(0x8ffff);
		    GPIO_SetBits(GPIOG,GPIO_Pin_14);
			GPIO_ResetBits(GPIOD,GPIO_Pin_13);
	}
}
